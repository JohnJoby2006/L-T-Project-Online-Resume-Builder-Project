$(document).ready(function () {
  // Update live preview
  $("#name, #contact, #summary, #skills").on("input", function () {
    $("#previewName").text($("#name").val() || "Your Name");
    $("#previewContact").text($("#contact").val() || "Email | Phone");
    $("#previewSummary").text($("#summary").val() || "Short professional summary will appear here...");
    $("#previewSkills").text($("#skills").val() || "Skills will appear here...");
  });
});

// Add Education
function addEducation() {
  let eduId = Date.now();
  $("#educationSection").append(`
    <div class="edu-entry mb-2" id="edu-${eduId}">
      <input type="text" class="form-control mb-1 edu-degree" placeholder="Degree / Course">
      <input type="text" class="form-control mb-1 edu-year" placeholder="Year">
      <input type="text" class="form-control mb-1 edu-institute" placeholder="Institute">
    </div>
  `);

  $(".edu-entry input").on("input", updateEducation);
}

function updateEducation() {
  $("#previewEducation").empty();
  $(".edu-entry").each(function () {
    let degree = $(this).find(".edu-degree").val();
    let year = $(this).find(".edu-year").val();
    let institute = $(this).find(".edu-institute").val();
    if (degree || year || institute) {
      $("#previewEducation").append(`<li>${degree} (${year}) - ${institute}</li>`);
    }
  });
}

// Add Experience
function addExperience() {
  let expId = Date.now();
  $("#experienceSection").append(`
    <div class="exp-entry mb-2" id="exp-${expId}">
      <input type="text" class="form-control mb-1 exp-role" placeholder="Job Title / Role">
      <input type="text" class="form-control mb-1 exp-year" placeholder="Year(s)">
      <textarea class="form-control mb-1 exp-desc" placeholder="Job Description"></textarea>
    </div>
  `);

  $(".exp-entry input, .exp-entry textarea").on("input", updateExperience);
}

function updateExperience() {
  $("#previewExperience").empty();
  $(".exp-entry").each(function () {
    let role = $(this).find(".exp-role").val();
    let year = $(this).find(".exp-year").val();
    let desc = $(this).find(".exp-desc").val();
    if (role || year || desc) {
      $("#previewExperience").append(`<li><b>${role}</b> (${year}) <br> ${desc}</li>`);
    }
  });
}

// Download Resume
function downloadResume() {
  window.print();
}
